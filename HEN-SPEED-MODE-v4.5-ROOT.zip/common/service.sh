#!/bin/sh


# Log create
rm -rf /data/media/0/Android/HEN/
mkdir /data/media/0/Android/HEN
HENLOG=/data/media/0/Android/HEN/runlogs.txt

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 666 "$1"
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}
echo -e "[$(date +"%Y-%m-%d %T")] Create Read|Write Function.\n" >> $EGLOG

sleep 20

echo -e "[$(date +"%Y-%m-%d %T")] Creating Fstrim Function" >> $EGLOG
function wait_sixty_second() {
sleep 60
}

function get_busybox_dir() {
BUSYBOX=$(find /data/adb/ -type f -name busybox | head -n 1)
}

function set_log_dir() {
LOG=/data/media/0/Android/fstrim.log
}

function get_exec_date() {
DATE=${date}
}

function empty_debug_log() {
echo "" > "$LOG"
}

function run_fstrim_debug() {
$BUSYBOX fstrim -v $1 >> "$LOG"
}

wait_sixty_second
get_busybox_dir
set_log_dir
empty_debug_log
echo -e "[$(date +"%Y-%m-%d %T")] Calling Function" >> $HENLOG

run_fstrim_debug /system
run_fstrim_debug /vendor
run_fstrim_debug /metadata
run_fstrim_debug /odm
run_fstrim_debug /system_ext
run_fstrim_debug /data
run_fstrim_debug /cache
echo -e "[$(date +"%Y-%m-%d %T")] Fstrim Done \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Turning off panic" >> $HENLOG
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom
echo -e "[$(date +"%Y-%m-%d %T")] Disabled panic \n" >> $HENLOG

echo "3" > /proc/sys/vm/drop_caches
echo -e "[$(date +"%Y-%m-%d %T")] Drop Caches " >> $HENLOG

echo "512" > /sys/devices/virtual/bdi/179:0/read_ahead_kb
echo -e "[$(date +"%Y-%m-%d %T")] SD Card Tweak \n" >> $HENLOG

for queue in /sys/block/mmcblk*/queue; do
echo "0" > $queue/add_random
echo "0" > $queue/iostats
echo "128" > $queue/read_ahead_kb
echo "64" > $queue/nr_requests
done
echo -e "[$(date +"%Y-%m-%d %T")] I/O Tweaked \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Turning off printk" >> $HENLOG
write_file_lock "/proc/sys/kernel/printk" "0 0 0 0"
write_file_lock "/proc/sys/kernel/printk_devkmsg" "off"
write_file_lock "/sys/module/printk/parameters/console_suspend" "Y"
write_file_lock "/sys/module/printk/parameters/cpu" "N"
write_file_lock "/sys/module/printk/parameters/ignore_loglevel" "Y"
write_file_lock "/sys/module/printk/parameters/pid" "N"
write_file_lock "/sys/module/printk/parameters/time" "N"
write_file_lock "/sys/kernel/printk_mode/printk_mode" "0"
echo -e "[$(date +"%Y-%m-%d %T")] Disabled printk \n" >> $HENLOG

echo '4:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '5:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '6:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '7:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '4:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '5:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '6:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '7:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '0:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '1:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '2:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '3:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
echo '0:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '1:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '2:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '3:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
echo -e "[$(date +"%Y-%m-%d %T")] CPU Performance \n" >> $HENLOG

echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms

echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us
echo '1500' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us	
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable
echo '1209600' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/pl
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable
echo '1574400' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/pl
echo -e "[$(date +"%Y-%m-%d %T")] CPU Settings \n" >> $HENLOG

chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable
echo -e "[$(date +"%Y-%m-%d %T")] Disable Fsync \n" >> $HENLOG

echo 0 >/sys/fs/selinux/log/deny_unknown
echo -e "[$(date +"%Y-%m-%d %T")] no logs selinux" >> $HENLOG

echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0rpmb/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable
echo -e "[$(date +"%Y-%m-%d %T")] I/O Tweaked \n" >> $HENLOG

echo "NO_GENTLE_FAIR_SLEEPERS:1" > /sys/kernel/debug/sched_features
echo "START_DEBIT:1" > /sys/kernel/debug/sched_features
echo "NEXT_BUDDY:1" > /sys/kernel/debug/sched_features
echo "LAST_BUDDY:1" > /sys/kernel/debug/sched_features
echo "STRICT_SKIP_BUDDY:1" > /sys/kernel/debug/sched_features
echo "CACHE_HOT_BUDDY:1" > /sys/kernel/debug/sched_features
echo "WAKEUP_PREEMPTION:1" > /sys/kernel/debug/sched_features
echo "NO_HRTICK:1" > /sys/kernel/debug/sched_features
echo "NO_DOUBLE_TICK:1" > /sys/kernel/debug/sched_features
echo "LB_BIAS:1" > /sys/kernel/debug/sched_features
echo "NONTASK_CAPACITY:1" > /sys/kernel/debug/sched_features
echo "NO_TTWU_QUEUE:1" > /sys/kernel/debug/sched_features
echo "NO_SIS_AVG_CPU:1" > /sys/kernel/debug/sched_features
echo "RT_PUSH_IPI:1" > /sys/kernel/debug/sched_features
echo "NO_FORCE_SD_OVERLAP:1" > /sys/kernel/debug/sched_features
echo "NO_RT_RUNTIME_SHARE:1" > /sys/kernel/debug/sched_features
echo "NO_LB_MIN:1" > /sys/kernel/debug/sched_features
echo "ATTACH_AGE_LOAD:1" > /sys/kernel/debug/sched_features
echo "ENERGY_AWARE:1" > /sys/kernel/debug/sched_features
echo "NO_MIN_CAPACITY_CAPPING:1" > /sys/kernel/debug/sched_features
echo "NO_FBT_STRICT_ORDER:1" > /sys/kernel/debug/sched_features
echo "EAS_USE_NEED_IDLE:1" > /sys/kernel/debug/sched_features
echo -e "[$(date +"%Y-%m-%d %T")] Kernel Tweaked \n" >> $HENLOG

echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
echo -e "[$(date +"%Y-%m-%d %T")] Memory Tuning Active \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Disabling Timer Migration \n" >> $HENLOG
echo 0 > /proc/sys/kernel/timer_migration
echo -e "[$(date +"%Y-%m-%d %T")] Done \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Applying tweak perf cpu time max percent \n" >> $HENLOG
echo 50 > /proc/sys/kernel/perf_cpu_time_max_percent
echo -e "[$(date +"%Y-%m-%d %T")] Done \n" >> $HENLOG



echo -e "[$(date +"%Y-%m-%d %T")] All Done!" >> $HENLOG