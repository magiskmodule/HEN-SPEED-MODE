SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

ui_print ""
ui_print "
┏┓╋┏┓╋╋╋╋╋┏━━━┓╋╋╋╋╋╋╋╋╋╋┏┓
┃┃╋┃┃╋╋╋╋╋┃┏━┓┃╋╋╋╋╋╋╋╋╋╋┃┃
┃┗━┛┣━━┳━┓┃┗━━┳━━┳━━┳━━┳━┛┃
┃┏━┓┃┃━┫┏┓╋━━┓┃┏┓┃┃━┫┃━┫┏┓┃
┃┃╋┃┃┃━┫┃┃┃┗━┛┃┗┛┃┃━┫┃━┫┗┛┃
┗┛╋┗┻━━┻┛┗┻━━━┫┏━┻━━┻━━┻━━┛
╋╋╋╋╋╋╋╋╋╋╋╋╋╋┃┃
╋╋╋╋╋╋╋╋╋╋╋╋╋╋┗┛"
ui_print " HEN SPEED MODE "
ui_print " Dev : HenVx "
ui_print " Versi : 5.1 FINAL "
ui_print ""
ui_print ""
ui_print " [LOG] Gaming Performance "
ui_print " [LOG] All In One Module  "
ui_print " [LOG] Experience By HenVx | Hendi "
ui_print ""
ui_print ""
ui_print " HSMD HEN SPEED MODE "
ui_print " Date : 10-9-2023 Build "
ui_print ""
ui_print " Done. "